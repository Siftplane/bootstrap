{{- define "siftplane-foundation.check" -}}
{{- if ne .Release.Name "siftplane-foundation" -}}
{{- fail "the shared foundation release must be named siftplane-foundation" -}}
{{- end -}}
{{- if ne .Release.Namespace .Values.namespace -}}
{{- fail "the foundation release namespace must match its configuration" -}}
{{- end -}}
{{- if ne .Chart.Version .Values.version -}}
{{- fail "the guard configuration must use the packaged foundation version" -}}
{{- end -}}
{{- if regexMatch ":[0-9]+/?$" .Values.kubernetes.url -}}
{{- if not (regexMatch (printf ":%d/?$" (int .Values.kubernetes.network.port)) .Values.kubernetes.url) -}}
{{- fail "API port must match its network policy destination" -}}
{{- end -}}
{{- else if ne (int .Values.kubernetes.network.port) 443 -}}
{{- fail "HTTPS API endpoints without an explicit port require network port 443" -}}
{{- end -}}
{{- end -}}
{{- define "siftplane-foundation.labels" -}}
app.kubernetes.io/name: siftplane-guard
app.kubernetes.io/instance: siftplane-foundation
app.kubernetes.io/component: admission-guard
deployment.siftplane.com/foundation: siftplane
{{- end -}}
{{- define "siftplane-foundation.config" -}}
cluster_uid = {{ .Values.cluster_uid | quote }}
version = {{ .Values.version | quote }}
listen = "0.0.0.0:8443"
[kubernetes]
endpoint = {{ .Values.kubernetes.url | quote }}
namespace = {{ .Release.Namespace | quote }}
token_file = "/var/run/secrets/siftplane/kubernetes/token"
ca_file = "/var/run/secrets/siftplane/kubernetes/ca.crt"
local_fixture = false
[tls]
ca_file = "/etc/siftplane/tls/ca.crt"
certificate_file = "/etc/siftplane/tls/tls.crt"
private_key_file = "/etc/siftplane/tls/tls.key"
{{- end -}}

{{- define "siftplane-foundation.workloadRules" -}}
{{- (.Files.Get "policies/admission.json" | fromJson).workload_rules | toYaml -}}
{{- end -}}
{{- define "siftplane-foundation.principal" -}}
{{- $policy := .Files.Get "policies/admission.json" | fromJson -}}
{{- $principal := $policy.principal -}}
{{- $_ := set $principal "rules" (concat $policy.workload_rules $principal.rules $policy.replicaset.rules $policy.pod.rules) -}}
{{- $_ := set $principal "clientConfig" (dict "service" (dict "name" "siftplane-guard" "namespace" .Release.Namespace "port" 443 "path" "/validate") "caBundle" (.Values.ca_certificate | b64enc)) -}}
{{- list $principal | toYaml -}}
{{- end -}}

{{- define "siftplane-foundation.namespaceProtection" -}}
{{- $policy := (.Files.Get "policies/admission.json" | fromJson).namespace -}}
{{- $_ := set $policy "clientConfig" (dict "service" (dict "name" "siftplane-guard" "namespace" .Release.Namespace "port" 443 "path" "/validate") "caBundle" (.Values.ca_certificate | b64enc)) -}}
{{- list $policy | toYaml -}}
{{- end -}}

{{- define "siftplane-foundation.replicaSetProtection" -}}
{{- $policy := (.Files.Get "policies/admission.json" | fromJson).replicaset -}}
{{- $_ := set $policy "clientConfig" (dict "service" (dict "name" "siftplane-guard" "namespace" .Release.Namespace "port" 443 "path" "/validate") "caBundle" (.Values.ca_certificate | b64enc)) -}}
{{- list $policy | toYaml -}}
{{- end -}}

{{- define "siftplane-foundation.podProtection" -}}
{{- $policy := (.Files.Get "policies/admission.json" | fromJson).pod -}}
{{- $_ := set $policy "clientConfig" (dict "service" (dict "name" "siftplane-guard" "namespace" .Release.Namespace "port" 443 "path" "/validate") "caBundle" (.Values.ca_certificate | b64enc)) -}}
{{- list $policy | toYaml -}}
{{- end -}}
