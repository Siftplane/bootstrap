{{- define "deployment-agent.check" -}}
{{- if ne .Release.Name "deployment-agent" -}}
{{- fail "the plane agent release must be named deployment-agent" -}}
{{- end -}}
{{- if ne .Release.Namespace .Values.identity.namespace -}}
{{- fail "the release namespace must match the registered agent identity" -}}
{{- end -}}
{{- if ne .Chart.Version .Values.agent_version -}}
{{- fail "the agent configuration must use the packaged release version" -}}
{{- end -}}
{{- if eq .Values.identity.credential_generation "0" -}}
{{- fail "the agent credential generation must be positive" -}}
{{- end -}}
{{- if eq .Values.action_generation "0" -}}
{{- fail "the accepted action generation must be positive" -}}
{{- end -}}
{{- if and .Values.document_policy (ne .Values.identity.plane "document") -}}
{{- fail "only document agents may enable document policy" -}}
{{- end -}}
{{- range (list .Values.kubernetes .Values.telemetry) -}}
{{- $explicitPort := regexMatch ":[0-9]+/?$" .url -}}
{{- if $explicitPort -}}
{{- if not (regexMatch (printf ":%d/?$" (int .network.port)) .url) -}}
{{- fail "endpoint port must match its network policy destination" -}}
{{- end -}}
{{- else if ne (int .network.port) 443 -}}
{{- fail "HTTPS endpoints without an explicit port require network port 443" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- define "deployment-agent.labels" -}}
app.kubernetes.io/name: deployment-agent
app.kubernetes.io/instance: deployment-agent
app.kubernetes.io/component: deployment-agent
deployment.siftplane.com/plane: {{ .Values.identity.plane | quote }}
deployment.siftplane.com/action-generation: {{ .Values.action_generation | quote }}
{{- end -}}
{{- define "deployment-agent.config" -}}
agent_version = {{ .Values.agent_version | quote }}
environment = "production"
listen = "0.0.0.0:8443"
region = {{ .Values.region | quote }}
otlp_endpoint = {{ .Values.telemetry.url | quote }}
telemetry_buffer = {{ .Values.telemetry_buffer }}
shutdown_seconds = 20
{{ if .Values.document_policy -}}
document_policy_file = "/etc/siftplane/policy/agent.toml"
{{ end }}
[identity]
schema_version = 1
agent_id = {{ .Values.identity.agent_id | quote }}
installation_id = {{ .Values.identity.installation_id | quote }}
deployment_id = {{ .Values.identity.deployment_id | quote }}
plane = {{ .Values.identity.plane | quote }}
cluster_uid = {{ .Values.identity.cluster_uid | quote }}
namespace = {{ .Values.identity.namespace | quote }}
namespace_uid = {{ .Values.identity.namespace_uid | quote }}
authority_incarnation = {{ .Values.identity.authority_incarnation | quote }}
credential_generation = {{ .Values.identity.credential_generation | quote }}
[kubernetes]
endpoint = {{ .Values.kubernetes.url | quote }}
namespace = {{ .Values.identity.namespace | quote }}
token_file = "/var/run/secrets/siftplane/kubernetes/token"
ca_file = "/var/run/secrets/siftplane/kubernetes/ca.crt"
local_fixture = false

[tls]
ca_file = "/etc/siftplane/tls/ca.crt"
certificate_file = "/etc/siftplane/tls/tls.crt"
private_key_file = "/etc/siftplane/tls/tls.key"
{{- end -}}
